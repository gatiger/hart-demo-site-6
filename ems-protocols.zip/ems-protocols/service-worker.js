const CACHE_NAME = 'hcems-protocols-v156';
const APP_SHELL = [
  './',
  './index.html',
  './styles.css',
  './app.js',
  './manifest.json',
  './assets/Hart_EMS_Banner.webp',
  './assets/legend-documentation.webp',
  './assets/legend-important.webp',
  './assets/legend-medical-control.webp',
  './assets/pediatric-pain-rating-scale.png',
  './assets/lvad-heartmate-ii.webp',
  './assets/lvad-heartware-hvad.webp',
  './assets/lvad-heartmate-3.webp',
  './assets/lvad-monitor-without-lvad.webp',
  './assets/lvad-monitor-with-lvad.webp',
  './page-images/page-211.jpg',
  './assets/adult-burn-tbsa-estimation.webp',
  './content/ems_protocols_content.json',
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(CACHE_NAME).then(cache => cache.addAll(APP_SHELL)));
  self.skipWaiting();
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k)))));
  self.clients.claim();
});
self.addEventListener('fetch', event => {
  event.respondWith(
    fetch(event.request).then(response => {
      const copy = response.clone();
      caches.open(CACHE_NAME).then(cache => cache.put(event.request, copy));
      return response;
    }).catch(() => caches.match(event.request))
  );
});
